import requests
import unittest

class TestProductAPI(unittest.TestCase):
    base_url = 'https://api.qa.soum.sa/api-v2/rest/api/v1/product/'

    def test_get_products_with_valid_params(self):
        # Test fetching products with valid parameters
        params = {'page number': 2, 'size': 3}
        headers = {'lang': 'en'}
        response = requests.get(self.base_url, params=params, headers=headers)

        self.assertEqual(response.status_code, 200)
        products = response.json()
        # Asserting response structure
        self.assertIn('data', products)
        self.assertIn('pagination', products)
        # Asserting correct pagination
        self.assertEqual(products['pagination']['current_page'], 2)
        self.assertEqual(len(products['data']), 3)

    def test_get_products_with_missing_params(self):
        # Test fetching products with missing parameters
        headers = {'lang': 'en'}
        response = requests.get(self.base_url, headers=headers)

        self.assertEqual(response.status_code, 400)

    def test_get_products_with_invalid_lang_header(self):
        # Test fetching products with invalid lang header
        params = {'page number': 2, 'size': 3}
        headers = {'lang': 'invalid_language'}
        response = requests.get(self.base_url, params=params, headers=headers)

        self.assertEqual(response.status_code, 400)

    def test_get_products_with_invalid_page_number(self):
        # Test fetching products with invalid page number
        params = {'page number': 'invalid', 'size': 3}
        headers = {'lang': 'en'}
        response = requests.get(self.base_url, params=params, headers=headers)

        self.assertEqual(response.status_code, 400)

    def test_get_products_with_negative_size(self):
        # Test fetching products with negative size parameter
        params = {'page number': 2, 'size': -3}
        headers = {'lang': 'en'}
        response = requests.get(self.base_url, params=params, headers=headers)

        self.assertEqual(response.status_code, 400)

    # Add more test cases as needed

if __name__ == '__main__':
    unittest.main()